﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Windows.ApplicationModel.AppService;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.UI.Xaml.Documents;

namespace AppServiceProvaiders.Tools
{
    public class MessageManager
    {
        private const string AREA_MESSAGE_KEY = "AREA_MESSAGE_KEY";
        private const string AREA_STATUS_KEY = "AREA_STATUS_KEY";
        private ApplicationDataContainer localSettings;
        private AppServiceConnection appServiceConnection;


        public string Message { get; set; }

        public MessageManager(AppServiceConnection appServiceConnection)
        {
            // Add the connection.
            this.localSettings = ApplicationData.Current.LocalSettings;
            this.appServiceConnection = appServiceConnection;
            localSettings.Values[AREA_STATUS_KEY] = "withoutMessage";
        }

        public MessageManager()
        {
            // Add the connection.
            this.localSettings = ApplicationData.Current.LocalSettings;
            localSettings.Values[AREA_STATUS_KEY] = "withoutMessage";
        }

        public async Task<AppServiceResponseStatus> SendMessage(string message)
        {
            //Create new Instance AppServiceConnection
            var appServiceConnection = new AppServiceConnection();
            appServiceConnection.AppServiceName = this.appServiceConnection.AppServiceName;
            appServiceConnection.PackageFamilyName = this.appServiceConnection.PackageFamilyName;

            var status = await appServiceConnection.OpenAsync();

            if (status == AppServiceConnectionStatus.Success)
            {
                // Call the service.
                var valueSendMessage = new ValueSet();
                valueSendMessage.Add("Status", "newMessage");
                valueSendMessage.Add("Message", message);

                var response = await appServiceConnection.SendMessageAsync(valueSendMessage);
                return response.Status;
            }

            return AppServiceResponseStatus.Failure;
        }        

        public async void ProcessMessage(AppServiceRequestReceivedEventArgs args)
        {
            var messageDeferral = args.GetDeferral();
            var messageRequest = args.Request.Message;

            //Message and Status
            var status = messageRequest["Status"] as string;

            try
            {
                switch (status)
                {
                    case "newMessage":                        
                        var message = messageRequest["Message"] as string;

                        //Área de memória Compartilhada
                        localSettings.Values[AREA_MESSAGE_KEY] = message;
                        localSettings.Values[AREA_STATUS_KEY] = status;

                        var returnData = new ValueSet();
                        returnData.Add("Status", "receivedMessage");

                        await args.Request.SendResponseAsync(returnData);
                        break;

                    case "receivedMessage":
                        
                        //Code Received Message

                        break;
                }
            }
            catch(Exception ex)
            {
                //Treatment Exception 
            }
            finally
            {
                messageDeferral.Complete();
            }
            

        }

        public Task<bool> isNewMessage()
        {
            var status = localSettings.Values[AREA_STATUS_KEY].ToString();
            return Task.FromResult(status == "newMessage" ? true : false);
        }

        public string GetMessage()
        {
            var message = localSettings.Values[AREA_MESSAGE_KEY].ToString();
            localSettings.Values[AREA_STATUS_KEY] = "readMessage";
            return message;
        }
    }
}

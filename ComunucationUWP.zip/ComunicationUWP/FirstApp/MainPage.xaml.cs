﻿using AppServiceProvaiders.Tools;
using System;
using Windows.ApplicationModel;
using Windows.ApplicationModel.AppService;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;

namespace FirstApp
{
    public sealed partial class MainPage : Page
    {
        const string SECOND_APP_PACKAGE_FAMILY_NAME = "4e086279-a7dd-4f1a-92ed-be02ab478a3e_k5bx3m1fq11y8";
        
        MessageManager messageManager;
        DispatcherTimer dispatcherTimer;

        public MainPage()
        {
            this.InitializeComponent();

            //CreateAppServiceConnection
            var appServiceConnection = new AppServiceConnection();
            appServiceConnection.AppServiceName = "com.comunicationuwp.secondappprovaider";
            appServiceConnection.PackageFamilyName = SECOND_APP_PACKAGE_FAMILY_NAME;

            //Config MessageManager
            messageManager = new MessageManager(appServiceConnection);

            //ChekingTimes
            dispatcherTimer = new DispatcherTimer();
            dispatcherTimer.Tick += DispatcherTimer_Tick;
            dispatcherTimer.Interval = new TimeSpan(0, 0, 0, 1);
            dispatcherTimer.Start();
        }

        private async void DispatcherTimer_Tick(object sender, object e)
        {
            await Dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal, GetMessageAppService);
        }

        private async void GetMessageAppService()
        {
            if (await messageManager.isNewMessage())
            {
                //Update UI
                ChatView.Foreground = new SolidColorBrush(Windows.UI.Colors.Cyan);
                ChatView.Text += $"\nSECOND APP: {messageManager.GetMessage()}";
            }
        }

        private async void SendBtn_Click(object sender, RoutedEventArgs e)
        {
            ChatView.Foreground = new SolidColorBrush(Windows.UI.Colors.White);
            ChatView.Text += $"\n   {Message.Text}";

            var status = await messageManager.SendMessage(Message.Text);

            if (status == AppServiceResponseStatus.Success)
            {
                Message.Text = String.Empty;
            }

        }

    }
}
